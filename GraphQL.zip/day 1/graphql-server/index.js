const { ApolloServer, gql, ValidationError, UserInputError } = require("apollo-server")

// const typeDefs = gql`
//     type Query {
//         hello: String!
//     }
// `;

// const resolvers = {
//     Query: {
//         hello: () => "Hello GraphQL"
//     }
// };

//schema definition and query definition (select, find)
const typeDefs = gql`
    type User {
        id: ID!
        name: String!
        email:String!
        orders: [Order!]!
    }

    type Order {
        id: ID!
        total: Float!
        status: String!
    }

    type Query {
        user(id: ID!): User
        userEmail(email: String!): User
        allUsers: [User!]!
    }

    type Mutation {
        createUser(id: ID!, name: String!, email: String!): User!
        updateUser(id: ID!, name: String!, email: String!): User
        deleteUser(id: ID!): Boolean!
    }
`;

// // dummy database
const users = [
    {id: "1", name: "Jane Doe", email: "jane.doe@example.com"},
    {id: "2", name: "Alice Smith", email: "alice.smith@example.com"},
    {id: "3", name: "Jolly Roger", email: "jolly.roger@example.com"}
];

const orders = [
  { id: "101", userId: "1", total: 1500, status: "SHIPPED" },
  { id: "102", userId: "3", total: 4500, status: "DELIVERED" },
  { id: "103", userId: "2", total: 2000, status: "PROCESSING" },
  { id: "104", userId: "1", total: 5000, status: "SHIPPED" },
];

// const users = []

let nextId = 1;

const isValidEmail = (email) => {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

const resolvers = {
    Query: {
        // user: (_, {id}) => users.find(u => u.id === id),
        user: (_, {id}) => {
            const user = users.find(u => u.id === id);
            if (!user) {
                throw new Error(`User with id ${id} not found`);
            }
            return user;
        },
        userEmail: (_, {email}) => users.find(u => u.email === email),
        // allUsers: () => users
        allUsers: () => {
            if (users.length === 0) {
                throw new Error("Collection Empty");
            }
            return users;
        }
    },
    User: {
        orders: (parent) => {
            return orders.filter(o => o.userId === parent.id);
        }
    },
    Mutation: {
        createUser: (_, { name, email }) =>{
            // const newUser = {id: String(nextId++), name, email};
            // users.push(newUser);
            // return newUser;

            //validate input
            if(!name || !email) {
                throw new UserInputError("Name and Email are required");
            }
            if(!isValidEmail(email)) {
                throw new UserInputError("Please enter a valid email");
            }
            if(users.find(u => u.email === email)) {
                throw new UserInputError("Email already exists")
            }

            const newUser = {
                id: String(nextId++),
                name,
                email
            };
            users.push(newUser);
            return newUser;
        },
        updateUser: (_, {id, name, email}) => {
            const user = users.find(u => u.id === id);
            if(!user) return null;
            user.name = name;
            user.email = email;
            return user;
        },
        deleteUser: (_, {id}) => {
            const index = users.findIndex(u => u.id === id);
            // let bool = false;
            if(index === -1) return false;
            users.splice(index, 1);
            // bool = true;
            return true;
        }
    }
}

const server = new ApolloServer({typeDefs, resolvers});

server.listen({port: 4000}).then(({url}) => {
    console.log(`Server listening at ${url}`)
});

