// import { typeDefs } from "./schema";
// import { users, posts } from "./data";

const { ApolloServer } = require("apollo-server");

const { typeDefs } = require("./schema.js")
const {users, posts} = require("./data.js")

const {createPostLoader} = require("./loader.js")

const resolvers = {
  Query: {
    userConnection: function() {
        const startIndex = 0;

        const perPage = 2;

        const selectedUsers = users.slice(
            startIndex,
            startIndex + perPage
        );

        const edges = selectedUsers.map(
            function(user) {
                return {
                    node: user,
                    cursor: user.id
                }
            }
        );

        const endCursor = edges.length > 0 ? edges[edges.length - 1].cursor:null;
        const hasNextPage = startIndex + perPage < users.length;
      

        return {
            edges: edges,
            pageInfo: {
                hasNextPage: hasNextPage,
                endCursor: endCursor
            }
        }
    },


    // users: () => {
    //   return users;
    // },

    users: function () {
        const offset = 0;
        const limit = 10;

        return users.slice(offset, offset + limit);
    },

    // users: (_, args) => {
    //     const start = args.offset;

    //     const end = start + args.limit;

    //     return users.slice(start, end);
    // },

    user: (_, {id}) => {
        return users.find(u => u.id === id);
    },

    // user: (_, { args }) => {
    //   return users.find((u) => u.id === args.id);
    // },

    posts: () => {
        return posts;
    }
  },

  User: {
    posts: (user, args, context) => {
        // console.log("Loading posts for user: ", user.id);

        // return posts.filter(
        //     post => post.authorId === user.id
        // )

        console.log("Postloader Context: ", context.postLoader);
        return context.postLoader.load(user.id);

    }
  },

  Post: {
    author: (post) => {
        return users.find(
            user => user.id === post.authorId
        )
    }
  },

  Mutation: {
    createUser: (_, args) => {
        const newUser = {
            id: String(users.length + 1),
            name: args.name,
            email: args.email
        };

        users.push(newUser);

        return newUser;
    }
  }
};

const server = new ApolloServer({
    typeDefs, 
    resolvers,
    context: () => ({
        postLoader: createPostLoader()
    })
});

server.listen({port: 4000}).then(({ url }) => {
    console.log(`server running at url: ${url}`)
})

// for apollo server 4+
// to install -> npm install @apollo/server
// const { url } = await startStandaloneServer(
//     server, {listen: {port: 4000}}
// )

