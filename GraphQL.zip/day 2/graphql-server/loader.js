const DataLoader = require("dataloader")

const {posts} = require("./data.js");

function createPostLoader() {
    return new DataLoader(async (userIds) => {
        console.log("Batch Load posts for ", userIds);

        return userIds.map((userId) => {
            return posts.filter(
                (post) => post.authorId === userId
            )
        })
    });
}

module.exports = {createPostLoader};