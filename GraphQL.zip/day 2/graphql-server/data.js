// export const users = [
const users = [
      {
        id: "1",
        name: "John",
        email: "john@example.com",
      },
      {
        id: "2",
        name: "Jane",
        email: "jane@example.com",
      },
      {
        id: "3",
        name: "Alice",
        email: "alice@example.com",
      },
      {
        id: "4",
        name: "Mary",
        email: "mary@example.com",
      },
      {
        id: "5",
        name: "David",
        email: "david@example.com",
      },
    ];

const posts = [
    {
        id: "101",
        title: "GraphQL Basics",
        content: "Introduction to GraphQL",
        authorId: "1"
    },
    {
        id: "102",
        title: "GraphQL Queries",
        content: "Working with queries",
        authorId: "2"
    },
    {
        id: "103",
        title: "MongoDB Basics",
        content: "Understanding MongoDB",
        authorId: "1"
    },
    {
        id: "104",
        title: "Apollo Server and Client",
        content: "Working with Apollo Server and Client",
        authorId: "3"
    }
];

module.exports = {users, posts}