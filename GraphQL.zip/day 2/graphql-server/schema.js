// defining the schema

// export const typeDefs = `#graphql
const typeDefs = `#graphql
    type User {
        id: ID!,
        name: String!,
        email: String!,
        posts: [Post!]!
    }

    type Post {
        id: ID!,
        title: String!,
        content: String,
        author: User!
    }

    type PageInfo {
        hasNextPage: Boolean!
        endCursor: String
    }

    type UserEdge {
        node: User!
        cursor: String!
    }

    type UserConnection {
        edges: [UserEdge!]!
        pageInfo: PageInfo!
    }

    type Query {
        users: [User!]!
        # users(offset: 0, limit: 10): [User!]!
        user(id: ID!): User
        posts: [Post!]!
        userConnection: UserConnection!
    }

    type Mutation {
        createUser(name: String!, email: String!): User!
    }
`

module.exports = { typeDefs }