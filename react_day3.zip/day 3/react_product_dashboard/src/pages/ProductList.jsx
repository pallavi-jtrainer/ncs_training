import { useState } from "react";


export default function ProductList({products, onUpdateProduct, onDeleteProduct}) {
    
    const [ editingProduct, setEditingProduct ] = useState(null);

    const handleEdit = (product) => {
        setEditingProduct({
            ...product,
        });
    };

    const handleCancelEdit = () => {
        setEditingProduct(null);
    }

    const handleUpdate = (e) => {
        e.preventDefault();

        onUpdateProduct(editingProduct);
        
        setEditingProduct(null);
    };

    const handleEditChange = (e) => {
        const {name, value} = e.target;

        setEditingProduct((prev) => ({
            ...prev,
            [name]: value
        }));
    };


    return (
      <div className="rounded-xl bg-white shadow-md">
        <div className="border-b border-gray-200 px-6 py-5 items-center justify-between">
          <div>
            <h3 className="text-xl font-bold text-gray-800">Product List</h3>
            <p className="mt-1 text-sm text-gray-500">
              {products.length} products available
            </p>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full  text-left text-sm">
              <thead className="bg-gray-50 text-xs uppercase text-gray-500">
                <tr>
                  <th className="px-6 py-4">Product</th>
                  <th className="px-6 py-4">Category</th>
                  <th className="px-6 py-4">Price</th>
                  <th className="px-6 py-4">Stock</th>
                  <th className="px-6 py-4">Status</th>
                  <th className="px-6 py-4">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {products.map((product) => (
                  <tr key={product.id} className="transition hover:bg-gray-50">
                    <td className="whitespace-nowrap px-6 py-4">
                      {product.name}
                    </td>
                    <td className="whitespace-nowrap px-6 py-4">
                      {product.category}
                    </td>
                    <td className="whitespace-nowrap px-6 py-4">
                      {product.price}
                    </td>
                    <td className="whitespace-nowrap px-6 py-4">
                      {product.stock}
                    </td>
                    <td className="whitespace-nowrap px-6 py-4">
                      {product.stock > 0 ? (
                        <span className="rounded-full bg-green-100 px-3 py-1 font-medium text-xs">
                          In Stock
                        </span>
                      ) : (
                        <span className="rounded-full bg-red-100 px-3 py-1 font-medium text-xs">
                          Out Of Stock
                        </span>
                      )}
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex justify-end gap-2">
                        <button
                          onClick={() => handleEdit(product)}
                          className="rounded-lg bg-yellow-100 px-3 py-2 text-xs font-medium text-yellow-700 hover:bg-yellow-200"
                        >
                          Edit
                        </button>
                        <button
                          onClick={() => onDeleteProduct(product.id)}
                          className="rounded-lg bg-red-100 px-3 py-2 text-xs font-medium text-red-700 hover:bg-red-200"
                        >
                          Delete
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          {/*Empty Array*/}
          {products.length == 0 && (
            <div className="px-6 py-12 text-center">
              <p className="text-gray-500">No Products Available</p>
            </div>
          )}
          {/* Edit Modal */}
          {editingProduct && (
            <div className="fixed inset-0 z-0 flex items-center justify-center bg-black/50 px-4 ">
              <div className="w-full max-w-lg rounded-xl bg-white p-6 shadow-xl">
                <div className="mb-6 flex items-center justify-between">
                  <div>
                    <h2 className="text-xl font-bold text-gray-800">
                      Edit Product
                    </h2>
                    <p className="text-sm text-gray-500">
                      Update The Product Details Below:
                    </p>
                  </div>

                  <button
                    className="text-2xl text-gray-400 hover:text-gray-700"
                    onClick={handleCancelEdit}
                  >
                    X
                  </button>
                </div>

                <form className="space-y-5" onSubmit={handleUpdate}>
                  <div>
                    <label className="mb-1 block text-sm font-medium text-gray-700 text-left">
                      Product Name:
                    </label>
                    <input
                      type="text"
                      name="name"
                      value={editingProduct.name}
                      onChange={handleEditChange}
                      disabled
                      placeholder="Enter Product Name"
                      className={`w-full rounded-lg border px-4 py-2.5 text-sm outline-none transition focus:ring-2 focus:ring-blue-500
                            `}
                    />
                  </div>
                  <div>
                    <label className="mb-1 block text-sm font-medium text-gray-700 text-left">
                      Category:
                    </label>

                    <select
                      name="category"
                      value={editingProduct.category}
                      onChange={handleEditChange}
                      disabled
                      className={`w-full rounded-lg border px-4 py-2.5 text-sm outline-none focus:ring-2 focus:ring-blue-500`}
                    >
                      <option value="">Select Category</option>
                      <option value="Electronics">Electronics</option>
                      <option value="Accessories">Accessories</option>
                      <option value="Furniture">Furniture</option>
                      <option value="Clothing">Clothing</option>
                    </select>
                  </div>
                  <div>
                    <label className="mb-1 block text-sm font-medium text-gray-700 text-left">
                      Product Price:
                    </label>
                    <input
                      type="number"
                      name="price"
                      value={editingProduct.price}
                      onChange={handleEditChange}
                      placeholder="Enter Product Price"
                      className={`w-full rounded-lg border px-4 py-2.5 text-sm outline-none transition focus:ring-2 focus:ring-blue-500
                            `}
                    />
                  </div>
                  <div>
                    <label className="mb-1 block text-sm font-medium text-gray-700 text-left">
                      Stock Quantity:
                    </label>
                    <input
                      type="number"
                      name="stock"
                      value={editingProduct.stock}
                      onChange={handleEditChange}
                      placeholder="Enter Stock Quantity"
                      className={`w-full rounded-lg border px-4 py-2.5 text-sm outline-none transition focus:ring-2 focus:ring-blue-500
                               `}
                    />
                  </div>
                  <button
                    type="submit"
                    className="rounded-lg bg-blue-600 px-5 py-2.5  font-medium text-white hover:bg-blue-700 text-sm"
                  >
                    Update Product
                  </button>
                  <button
                    type="button"
                    onClick={handleCancelEdit}
                    className="rounded-lg bg-gray-600 px-5 py-2.5  font-medium text-white hover:bg-gray-700 text-sm"
                  >
                    Cancel
                  </button>
                </form>
              </div>
            </div>
          )}
        </div>
      </div>
    );
}