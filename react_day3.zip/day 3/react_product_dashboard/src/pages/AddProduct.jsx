import { useState } from "react";


export default function AddProduct({onAddProduct}) {
    
    const [ formData, setFormData ] = useState({
        name: "",
        category: "",
        price: "",
        stock: ""
    });

    const [ errors, setErrors ] = useState({});

    const handleChange = (e) => {
        const {name, value} = e.target;

        setFormData((prev) => ({
            ...prev,
            [name] : value,
        }))
    }

    const validateForm = () => {
        const newErrors = {};

        if(!formData.name.trim()) {
            newErrors.name = "Product Name is Required";
        }

        if (!formData.category.trim()) {
          newErrors.category = "Product Category is Required";
        }

        if (!formData.price || Number(formData.price) <= 0) {
          newErrors.price = "Enter a Valid Price";
        }

        if (!formData.stock || Number(formData.stock) <= 0) {
          newErrors.stock = "Enter a Valid Stock Quantity";
        }

        setErrors(newErrors);

        return Object.keys(newErrors).length === 0;
    }

    const handleSubmit = (e) => {
        e.preventDefault();

        if(!validateForm()) {
            return;
        }

        onAddProduct(formData);

        setFormData({
          name: "",
          category: "",
          price: "",
          stock: "",
        });

        setErrors({});

    }

    return (
      <div className="rounded-xl bg-white p-6 shadow-md">
        <h2 className="mb-1 text-xl font-bold text-gray-800">Add Product</h2>
        <p className="mb-6 text-sm text-gray-500">
          Enter The Product Details Below:
        </p>

        <form className="space-y-5" onSubmit={handleSubmit}>
          <div>
            <label className="mb-1 block text-sm font-medium text-gray-700 text-left">
              Product Name:
            </label>
            <input
              type="text"
              name="name"
              value={formData.name}
              onChange={handleChange}
              placeholder="Enter Product Name"
              className={`w-full rounded-lg border px-4 py-2.5 text-sm outline-none transition focus:ring-2 focus:ring-blue-500
                        ${errors.name ? "border-red-500" : "border-gray-300"}`}
            />
            {errors.name && (
              <p className="mt-1 text-xs text-red-500">{errors.name}</p>
            )}
          </div>
          <div>
            <label className="mb-1 block text-sm font-medium text-gray-700 text-left">
              Category:
            </label>

            <select
              name="category"
              value={formData.category}
              onChange={handleChange}
              className={`w-full rounded-lg border px-4 py-2.5 text-sm outline-none focus:ring-2 focus:ring-blue-500
                    ${errors.category ? "border-red-500" : "border-gray-300"}`}
            >
              <option value="">Select Category</option>
              <option value="Electronics">Electronics</option>
              <option value="Accessories">Accessories</option>
              <option value="Furniture">Furniture</option>
              <option value="Clothing">Clothing</option>
            </select>
            {errors.category && (
              <p className="mt-1 text-xs text-red-500">{errors.category}</p>
            )}
          </div>
          <div>
            <label className="mb-1 block text-sm font-medium text-gray-700 text-left">
              Product Price:
            </label>
            <input
              type="number"
              name="price"
              value={formData.price}
              onChange={handleChange}
              placeholder="Enter Product Price"
              className={`w-full rounded-lg border px-4 py-2.5 text-sm outline-none transition focus:ring-2 focus:ring-blue-500
                        ${errors.price ? "border-red-500" : "border-gray-300"}`}
            />
            {errors.price && (
              <p className="mt-1 text-xs text-red-500">{errors.price}</p>
            )}
          </div>
          <div>
            <label className="mb-1 block text-sm font-medium text-gray-700 text-left">
              Stock Quantity:
            </label>
            <input
              type="number"
              name="stock"
              value={formData.stock}
              onChange={handleChange}
              placeholder="Enter Stock Quantity"
              className={`w-full rounded-lg border px-4 py-2.5 text-sm outline-none transition focus:ring-2 focus:ring-blue-500
                        ${errors.stock ? "border-red-500" : "border-gray-300"}`}
            />
            {errors.stock && (
              <p className="mt-1 text-xs text-red-500">{errors.stock}</p>
            )}
          </div>
          <button
            type="submit"
            className="w-full rounded-lg bg-blue-600 px-4 py-3  font-medium text-white transition hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2
            "
          >
            Add Product
          </button>
        </form>
      </div>
    );
}