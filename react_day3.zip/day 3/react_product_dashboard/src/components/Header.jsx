
// import '../styles/styles.css';

import { useState } from "react";
import AddProduct from "../pages/AddProduct";
import ProductList from "../pages/ProductList";

// import ProductCard from "./ProductCard";

export default function Header() {
    //const product = {id: 1, name: 'Laptop', price: '$750'}

    const [ products, setProducts ] = useState([
      {
        id: 1,
        name: "Laptop",
        price: 65000,
        category: "Electronics",
        stock: 10,
      },
      {
        id: 2,
        name: "Bluetooth Mouse",
        price: 3500,
        category: "Accessories",
        stock: 0,
      },
      {
        id: 3,
        name: "Keyboard",
        price: 2500,
        category: "Accessories",
        stock: 15,
      },
    ]);

    /*Add Product */
    const addProduct = (product) => {
        const newProduct = {
            ...product,
            id: products.length + 1,
            name: product.name,
            category: product.category,
            price: Number(product.price),
            stock: Number(product.stock)
        };

        setProducts((prev) => [
            ...prev, newProduct
        ]);
    }
    /* Update Product */
    const updateProduct = (updatedProduct) => {
        setProducts((prevProducts) =>
            prevProducts.map((product) =>
                product.id === updatedProduct.id
                ? {
                    ...updatedProduct,
                    price: Number(updatedProduct.price),
                    stock: Number(updatedProduct.stock)
                } : product
            ) 
        );
    };

    //Delete product
    const deleteProduct = (id) => {
        const confirm = window.confirm("Are you sure you want to delete this product?");

        if(!confirm) {
            return;
        }

        setProducts((prev) => 
            prev.filter((product) => product.id !== id)
        );
    };

    return (
      <div className="min-h-screen bg-gray-100">
        <header className="bg-blue-500 text-white shadow-md">
          <div className="mx-auto mx-w-7xl px-6 py-5">
            <h1 className="text-2xl font-bold">Product Management</h1>
            <p className="mt-1 text-sm text-blue-100">Manage your Products</p>
          </div>
        </header>
        <main className="mx-auto grid mx-w-7xl gap-6 px-6 py-8 lg:grid-cols-3">
          <div className="lg:col-span-1">
            <AddProduct onAddProduct={addProduct} />
          </div>

          <div className="lg:col-span-2">
            <ProductList products={products}
                onUpdateProduct={updateProduct}
                onDeleteProduct={deleteProduct}
            />
          </div>
        </main>
      </div>
    );
}