// import {useMemo} from 'react';
import {Link } from 'react-router';
import {useProducts} from '../context/ProductContext';

export default function Dashboard() {
    const  { products = [], loading } = useProducts();

    console.log(products);

    const totalStock = products.reduce((total, product) => {
        return total + Number(product.stock || 0);
    }, 0);

    const inventoryValue = products.reduce((total, product) => {
        return total + 
        Number(product.price || 0) *
        Number(product.stock || 0);
    }, 0);

    const categories = new Set(
        products.map(product => product.category)
    ).size;

    if(loading) {
        return(
            <div className="p-8">
                Loading Dashboard ..................
            </div>
        )
    }

    return (
      <div>
        <div className="mb-8">
          <h1 className="text-3xl font-bold">Dashboard</h1>
          <p className="text-gray-600">Product Inventory Overview</p>
        </div>

        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
          <div className="rounded-xl bg-white p-6 shadow">
            <p className="text-sm text-gray-500">Total Products</p>
            <p className="mt-2 text-3xl font-bold">{products.length}</p>
          </div>
          <div className="rounded-xl bg-white p-6 shadow">
            <p className="text-sm text-gray-500">Total Stock</p>
            <p className="mt-2 text-3xl font-bold">{totalStock}</p>
          </div>
          <div className="rounded-xl bg-white p-6 shadow">
            <p className="text-sm text-gray-500">Categories</p>
            <p className="mt-2 text-3xl font-bold">{categories}</p>
          </div>
          <div className="rounded-xl bg-white p-6 shadow">
            <p className="text-sm text-gray-500">Inventory Value</p>
            <p className="mt-2 text-3xl font-bold">{inventoryValue}</p>
          </div>
        </div>
        <div className="mt-8 rounded-xl bg-white p-8 shadow">
          <h2 className="mb-3 text-xl font-bold">Product Management</h2>
          <p className="mb-6 text-gray-500">Manage Your Products</p>
          <Link
            to="/products"
            className="inline-block rounded-lg bg-blue-600 px-5 py-3 text-white"
          >
            View Products
          </Link>
        </div>
      </div>
    );
}