import {
    createContext,
    useContext,
    useState,
    useEffect
} from 'react';

import {
    getProducts
} from '../services/productService';

//create a context
const ProductContext = createContext();

export function ProductProvider({children}) {
    const [ products, setProducts ] = useState([]);

    const [ loading, setLoading ] = useState(false);

    const [ error, setError ] = useState(null);

    // Get All Products
    const loadProducts = async () => {
        try {
            setLoading(true);
            setError(null);

            const data = await getProducts();
            setProducts(data);

        } catch (error) {
            setError(error.message);
        } finally {
            setLoading(false);
        }
    };

    // Load the products when application starts
    useEffect(() => {
        loadProducts();
    }, []);

    const value = {
        products, loading, error, loadProducts
    };

    return (
        <ProductContext.Provider value={value}>
            {children}
        </ProductContext.Provider>
    );
}

export function useProducts() {
    return useContext(
        ProductContext
    );
}