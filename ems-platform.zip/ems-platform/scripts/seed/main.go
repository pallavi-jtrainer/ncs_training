package main

import (
	"context"
	"log"
	"time"

	"ems-platform/internal/config"
	"ems-platform/internal/models"
	"ems-platform/internal/repository"
	"ems-platform/internal/services"

	"github.com/joho/godotenv"
)

func main() {

	_ = godotenv.Load()

	cfg := config.LoadConfig()

	ctx := context.Background()

	repo, err := repository.NewMongoRepository(
		ctx,
		cfg,
	)

	if err != nil {
		log.Fatal(err)
	}

	defer repo.Close(ctx)

	svc := services.New(repo)

	// ------------------------------------------------
	// ADMIN
	// ------------------------------------------------

	admin, err := svc.CreateUser(
		ctx,
		&models.User{
			Name:   "EMS Administrator",
			Email:  "admin@ems.local",
			Role:   "ADMIN",
			Status: "ACTIVE",
		},
	)

	if err != nil {
		log.Fatal(err)
	}

	// ------------------------------------------------
	// ORGANIZER
	// ------------------------------------------------

	organizer, err := svc.CreateUser(
		ctx,
		&models.User{
			Name:   "Event Organizer",
			Email:  "organizer@ems.local",
			Role:   "ORGANIZER",
			Status: "ACTIVE",
		},
	)

	if err != nil {
		log.Fatal(err)
	}

	// ------------------------------------------------
	// ATTENDEE
	// ------------------------------------------------

	attendee, err := svc.CreateUser(
		ctx,
		&models.User{
			Name:   "Demo Attendee",
			Email:  "attendee@ems.local",
			Role:   "ATTENDEE",
			Status: "ACTIVE",
		},
	)

	if err != nil {
		log.Fatal(err)
	}

	// ------------------------------------------------
	// CATEGORY
	// ------------------------------------------------

	category, err := svc.CreateCategory(
		ctx,
		models.Category{
			Name:        "Technology",
			Description: "Technology events",
		},
	)

	if err != nil {
		log.Fatal(err)
	}

	// ------------------------------------------------
	// EVENT
	// ------------------------------------------------

	event, err := svc.CreateEvent(
		ctx,
		models.Event{
			Title:       "Go Developer Workshop",
			Description: "Learn Go, Gin and MongoDB",
			CategoryID:  category.ID,
			OrganizerID: organizer.ID,
			Venue:       "Bengaluru",
			EventDate: time.Now().
				UTC().
				AddDate(0, 0, 14),
			RegistrationDeadline: time.Now().
				UTC().
				AddDate(0, 0, 10),
			Capacity:   50,
		},
	)

	if err != nil {
		log.Fatal(err)
	}

	// Publish event.
	event, err = svc.PublishEvent(
		ctx,
		event.ID,
	)

	if err != nil {
		log.Fatal(err)
	}

	// ------------------------------------------------
	// TICKET
	// ------------------------------------------------

	ticket, err := svc.CreateTicket(
		ctx,
		models.Ticket{
			EventID:    event.ID,
			TicketType: "Free",
			Price:      0,
			Quantity:   50,
			Status:     "OPEN",
		},
	)

	if err != nil {
		log.Fatal(err)
	}

	log.Println("================================")
	log.Println("EMS SEED COMPLETE")
	log.Println("================================")

	log.Println("Admin ID:", admin.ID)
	log.Println("Organizer ID:", organizer.ID)
	log.Println("Attendee ID:", attendee.ID)
	log.Println("Category ID:", category.ID)
	log.Println("Event ID:", event.ID)
	log.Println("Ticket ID:", ticket.ID)
}