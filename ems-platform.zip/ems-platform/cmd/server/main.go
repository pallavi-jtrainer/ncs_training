package main

import (
	"context"
	"ems-platform/internal/config"
	"ems-platform/internal/handlers"
	"ems-platform/internal/repository"
	"ems-platform/internal/services"
	"log"

	"github.com/gin-gonic/gin"
	"github.com/joho/godotenv"
)

func main() {
	// load .env file (if available)
	_ = godotenv.Load()

	//load application config
	cfg := config.LoadConfig()

	ctx := context.Background()

	// connect to mongoDB
	repo, err := repository.NewMongoRepository(ctx, cfg,)

	if err != nil {
		log.Fatal(
			"MongoDB connection failed",
			err,
		)
	}

	defer repo.Close(ctx)

	//create service
	svc := services.New(repo)

	//create http Handlers
	handler := handlers.New(svc)

	//create the gin router
	router := gin.Default()

	//register the REST endpoints
	handler.RegisterRoutes(router)

	log.Printf(
		"EMS Platform running on http://localhost:%s",
		cfg.Port,
	)

	//start http server
	if err := router.Run(
		":" + cfg.Port,
	); err != nil {
		log.Fatal(err)
	}
}
