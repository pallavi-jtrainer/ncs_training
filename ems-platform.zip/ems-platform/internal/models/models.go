package models

import "time"

//user representation
type User struct {
	ID string `bson:"_id" json: "id"`
	Name string `bson:"name" json: "name"`
	Email string `bson:"email" json: "email"`
	Role string `bson:"role" json: "role"`
	Status string `bson:"status" json: "status"`
	CreatedAt time.Time `bson:"createdAt" json: "createdAt"`
	UpdatedAt time.Time `bson:"updatedAt" json: "updatedAt"`
}

//category representation
type Category struct {
	ID string `bson:"_id" json: "id"`
	Name string `bson:"name" json: "name"`
	Description string `bson:"description" json: "description"`
	CreatedAt time.Time `bson:"createdAt" json: "createdAt"`
}

//event representation
type Event struct {
	ID string `bson:"_id" json: "id"`
	Title string `bson:"title" json: "title"`
	Description string `bson:"description" json: "description"`
	CategoryID string `bson:"categoryId" json: "categoryId"`
	OrganizerID string `bson:"organizerId" json: "organizerId"`
	Venue string `bson:"venue" json: "venue"`
	EventDate time.Time `bson:"eventDate" json: "eventDate"`
	RegistrationDeadline time.Time `bson:"registrationDeadline" json: "registrationDeadline"`
	Capacity int `bson:"capacity" json: "capacity"`
	AvailableSeats int `bson:"availableSeats" json: "availableSeats"`
	Status string `bson:"status" json: "status"`
	CreatedAt time.Time `bson:"createdAt" json: "createdAt"`
	UpdatedAt time.Time `bson:"updatedAt" json: "updatedAt"`
}

//ticket representation
type Ticket struct {
	ID string `bson:"_id" json: "id"`
	EventID string `bson:"eventId" json: "eventId"`
	TicketType string `bson:"ticketType" json: "ticketType"`
	Price float64 `bson:"price" json: "price"`
	Status string `bson:"status" json: "status"`
	Quantity int `bson:"quantity" json: "quantity"`
	SoldCount int `bson:"soldCount" json: "soldCount"`
	CreatedAt time.Time `bson:"createdAt" json: "createdAt"`
}

//registration representation
type Registration struct {
	ID string `bson:"_id" json: "id"`
	EventID string `bson:"eventId" json: "eventId"`
	UserID string `bson:"userId" json: "userId"`
	RegisteredAt time.Time `bson:"registeredAt" json: "registeredAt"`
	TicketID string `bson:"ticketId" json: "ticketId"`
	Status string `bson:"status" json: "status"`
	CancelledAt *time.Time `bson:"cancelledAt,omitempty" json: "cancelledAt,omitempty"`
}

//attendance representation
type Attendance struct {
	ID string `bson:"_id" json: "id"`
	EventID string `bson:"eventId" json: "eventId"`
	RegistrationID string `bson:"registrationId" json: "registrationId"`
	CheckedInAt time.Time `bson:"checkedInAt" json: "checkedInAt"`
	CheckedInBy string `bson:"checkedInBy" json: "checkedInBy"`
	Status string `bson:"status" json: "status"`
}