package config

import "os"

// Config holds the configuration values for the application
type Config struct {
	MongoURI string
	MongoDBName string
	Port string
}

// LoadConfig loads the configuration values from environment variables
func LoadConfig() Config {
	port := os.Getenv("PORT")
	
	if port == "" {
		port = "8080" // default port
	}

	database := os.Getenv("MONGO_DATABASE")

	if database == "" {
		database = "ems_platform"
	}

	mongo_uri := os.Getenv("MONGO_URI")

	if mongo_uri == "" {
		mongo_uri = "mongodb://localhost:27017"
	}

	return Config {
		Port: port,
		MongoURI: mongo_uri,
		MongoDBName: database,
	}
}