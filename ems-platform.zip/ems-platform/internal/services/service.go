package services

import (
	"context"
	"ems-platform/internal/models"
	"ems-platform/internal/repository"
	"errors"
	"strings"
	"time"

	"github.com/google/uuid"
	"go.mongodb.org/mongo-driver/v2/bson"
	"go.mongodb.org/mongo-driver/v2/mongo"
	"go.mongodb.org/mongo-driver/v2/mongo/options"
)

type Service struct {
	db *mongo.Database
}

func New(repo *repository.MongoRepository) *Service {
	return &Service{
		db: repo.DB,
	}
}

func (s *Service) collection(name string) *mongo.Collection {
	return s.db.Collection(name)
}


//helper methods - Generic
func findMany[T any] (
	ctx context.Context,
	collection *mongo.Collection,
	filter bson.M,
) ([]T, error) {
	cursor, err := collection.Find(ctx, filter)

	if err != nil {
		return nil, err
	}

	defer cursor.Close(ctx)

	var results []T

	if err := cursor.All(ctx, &results); err != nil {
		return nil, err
	}

	if results == nil {
		results = []T{}
	}

	return results, nil
}

func findOne[T any] (
	ctx context.Context,
	collection *mongo.Collection,
	filter bson.M,
) (*T, error) {
	var result T

	err := collection.FindOne(ctx, filter).Decode(&result)

	if err == mongo.ErrNoDocuments {
		return nil, nil
	}
	if err != nil {
		return nil, err
	}

	return &result, nil
}

func findOneAndUpdate[T any] (
	ctx context.Context,
	collection *mongo.Collection,
	filter bson.M,
	update bson.M,
) (*T, error) {
	var result T

	opts := options.FindOneAndUpdate().SetReturnDocument(options.After)

	err := collection.FindOneAndUpdate(ctx, filter, update, opts).Decode(&result)

	if err == mongo.ErrNoDocuments {
		return nil, errors.New("Document not found with id: " + filter["_id"].(string))
	}

	if err != nil {
		return nil, err
	}

	return &result, nil
}

/*------------- CRUD for User ---------------*/
//1. Add a new user
func (s *Service) CreateUser(
	ctx context.Context,
	user *models.User,
) (*models.User, error) {

	if strings.TrimSpace(user.Name) == "" {
		return nil, errors.New("Name is Required")
	}

	if strings.TrimSpace(user.Email) == "" {
		return nil, errors.New("Email is Required")
	}

	user.ID = uuid.NewString()

	user.Email = strings.ToLower(strings.TrimSpace(user.Email))

	if user.Role == "" {
		user.Role = "ATTENDEE"
	}

	if user.Status == "" {
		user.Status = "ACTIVE"
	}

	now := time.Now().UTC()

	user.CreatedAt = now
	user.UpdatedAt = now

	var existing models.User

	//check if user with the same email already exists
	err := s.collection("users").FindOne(
		ctx, 
		bson.M{"email": user.Email},
	).Decode(&existing)

	if err ==nil {
		return nil, errors.New("User with this email already exists")
	} 

	//insert a new user
	_, err = s.collection("users").InsertOne(ctx, user)

	if err != nil {
		return nil, err
	}

	return user, nil
}

// 2. get a user by id
func (s *Service) GetUserById(
	ctx context.Context,
	id string,
)(*models.User, error) {
	return findOne[models.User](ctx, s.collection("users"), bson.M{"_id": id})
}

//3. get all users
func (s *Service) GetAllUsers(
	ctx context.Context,
) ([]models.User, error) {
	return findMany[models.User](ctx, s.collection("users"), bson.M{})
}

//4. update user
func (s *Service) UpdateUser(
	ctx context.Context,
	id string,
	user models.User,
)(*models.User, error) {
	update := bson.M{
		"$set": bson.M{
			"name": user.Name,
			"role": user.Role,
			"status": user.Status,
			"updatedAt": time.Now().UTC(),

		},
	}

	return findOneAndUpdate[models.User](
		ctx, s.collection("users"), bson.M{"_id": id}, update,
	)
}

/* --------- CRUD for Category -------------*/
func (s *Service) CreateCategory(
	ctx context.Context,
	category models.Category,
) (*models.Category, error) {

	if strings.TrimSpace(category.Name) == "" {
		return nil, errors.New("category name is required")
	}

	category.ID = uuid.NewString()
	category.CreatedAt = time.Now().UTC()

	_, err := s.collection("categories").
		InsertOne(ctx, category)

	if err != nil {
		return nil, err
	}

	return &category, nil
}

func (s *Service) GetCategories(
	ctx context.Context,
) ([]models.Category, error) {

	return findMany[models.Category](
		ctx,
		s.collection("categories"),
		bson.M{},
	)
}

func (s *Service) GetCategory(
	ctx context.Context,
	id string,
) (*models.Category, error) {

	return findOne[models.Category](
		ctx,
		s.collection("categories"),
		bson.M{"_id": id},
	)
}

func (s *Service) UpdateCategory(
	ctx context.Context,
	id string,
	category models.Category,
) (*models.Category, error) {

	update := bson.M{
		"$set": bson.M{
			"name":        category.Name,
			"description": category.Description,
		},
	}

	return findOneAndUpdate[models.Category](
		ctx,
		s.collection("categories"),
		bson.M{"_id": id},
		update,
	)
}

/* --------- CRUD for Event -------------*/
func (s *Service) CreateEvent(
	ctx context.Context,
	event models.Event,
) (*models.Event, error) {

	if strings.TrimSpace(event.Title) == "" {
		return nil, errors.New("event title is required")
	}

	if event.Capacity <= 0 {
		return nil, errors.New(
			"capacity must be greater than zero",
		)
	}

	category, err := s.GetCategory(
		ctx,
		event.CategoryID,
	)

	if err != nil || category == nil {
		return nil, errors.New("category not found")
	}

	organizer, err := s.GetUserById(
		ctx,
		event.OrganizerID,
	)

	if err != nil || organizer == nil {
		return nil, errors.New("organizer not found")
	}

	if organizer.Role != "ORGANIZER" &&
		organizer.Role != "ADMIN" {

		return nil, errors.New(
			"user is not an organizer or admin",
		)
	}

	event.ID = uuid.NewString()

	event.AvailableSeats = event.Capacity
	event.Status = "DRAFT"
	event.CreatedAt = time.Now().UTC()

	_, err = s.collection("events").
		InsertOne(ctx, event)

	if err != nil {
		return nil, err
	}

	return &event, nil
}

func (s *Service) GetEvents(
	ctx context.Context,
	search string,
	categoryID string,
	featured *bool,
) ([]models.Event, error) {

	filter := bson.M{}

	if search != "" {
		filter["$or"] = bson.A{
			bson.M{
				"title": bson.M{
					"$regex":   search,
					"$options": "i",
				},
			},
			bson.M{
				"description": bson.M{
					"$regex":   search,
					"$options": "i",
				},
			},
		}
	}

	if categoryID != "" {
		filter["categoryId"] = categoryID
	}

	if featured != nil {
		filter["isFeatured"] = *featured
	}

	return findMany[models.Event](
		ctx,
		s.collection("events"),
		filter,
	)
}

func (s *Service) GetEvent(
	ctx context.Context,
	id string,
) (*models.Event, error) {

	return findOne[models.Event](
		ctx,
		s.collection("events"),
		bson.M{"_id": id},
	)
}

func (s *Service) UpdateEvent(
	ctx context.Context,
	id string,
	event models.Event,
) (*models.Event, error) {

	update := bson.M{
		"$set": bson.M{
			"title":                event.Title,
			"description":          event.Description,
			"categoryId":           event.CategoryID,
			"organizerId":          event.OrganizerID,
			"venue":                event.Venue,
			"eventDate":            event.EventDate,
			"registrationDeadline": event.RegistrationDeadline,
			"capacity":             event.Capacity,
			"availableSeats":       event.AvailableSeats,
			"status":               event.Status,
			"updatedAt":            time.Now().UTC(),
		},
	}

	return findOneAndUpdate[models.Event](
		ctx,
		s.collection("events"),
		bson.M{"_id": id},
		update,
	)
}

func (s *Service) DeleteEvent(
	ctx context.Context,
	id string,
) error {

	result, err := s.collection("events").
		DeleteOne(
			ctx,
			bson.M{"_id": id},
		)

	if err != nil {
		return err
	}

	if result.DeletedCount == 0 {
		return errors.New("event not found")
	}

	return nil
}

func (s *Service) PublishEvent(
	ctx context.Context,
	id string,
) (*models.Event, error) {

	return findOneAndUpdate[models.Event](
		ctx,
		s.collection("events"),
		bson.M{"_id": id},
		bson.M{
			"$set": bson.M{
				"status": "PUBLISHED",
			},
		},
	)
}

/* --------- CRUD for Ticket -------------*/
func (s *Service) CreateTicket(
	ctx context.Context,
	ticket models.Ticket,
) (*models.Ticket, error) {

	if ticket.EventID == "" {
		return nil, errors.New("eventId is required")
	}

	if ticket.Quantity <= 0 {
		return nil, errors.New(
			"quantity must be greater than zero",
		)
	}

	if ticket.Price < 0 {
		return nil, errors.New(
			"price cannot be negative",
		)
	}

	event, err := s.GetEvent(
		ctx,
		ticket.EventID,
	)

	if err != nil || event == nil {
		return nil, errors.New("event not found")
	}

	ticket.ID = uuid.NewString()

	if ticket.Status == "" {
		ticket.Status = "OPEN"
	}

	_, err = s.collection("tickets").
		InsertOne(ctx, ticket)

	if err != nil {
		return nil, err
	}

	return &ticket, nil
}

func (s *Service) GetTickets(
	ctx context.Context,
	eventID string,
) ([]models.Ticket, error) {

	filter := bson.M{}

	if eventID != "" {
		filter["eventId"] = eventID
	}

	return findMany[models.Ticket](
		ctx,
		s.collection("tickets"),
		filter,
	)
}

func (s *Service) GetTicket(
	ctx context.Context,
	id string,
) (*models.Ticket, error) {

	return findOne[models.Ticket](
		ctx,
		s.collection("tickets"),
		bson.M{"_id": id},
	)
}

func (s *Service) UpdateTicket(
	ctx context.Context,
	id string,
	ticket models.Ticket,
) (*models.Ticket, error) {

	update := bson.M{
		"$set": bson.M{
			"ticketType": ticket.TicketType,
			"price":      ticket.Price,
			"quantity":   ticket.Quantity,
			"status":     ticket.Status,
		},
	}

	return findOneAndUpdate[models.Ticket](
		ctx,
		s.collection("tickets"),
		bson.M{"_id": id},
		update,
	)
}

func (s *Service) DeleteTicket(
	ctx context.Context,
	id string,
) error {

	result, err := s.collection("tickets").
		DeleteOne(
			ctx,
			bson.M{"_id": id},
		)

	if err != nil {
		return err
	}

	if result.DeletedCount == 0 {
		return errors.New("ticket not found")
	}

	return nil
}

/* ------- Registration Business Logic --------- */
func (s *Service) CreateRegistration(
	ctx context.Context,
	reg models.Registration,
) (*models.Registration, error) {

	user, err := s.GetUserById(
		ctx,
		reg.UserID,
	)

	if err != nil || user == nil {
		return nil, errors.New("user not found")
	}

	event, err := s.GetEvent(
		ctx,
		reg.EventID,
	)

	if err != nil || event == nil {
		return nil, errors.New("event not found")
	}

	if event.Status != "PUBLISHED" {
		return nil, errors.New(
			"event is not published",
		)
	}

	if event.RegistrationDeadline.Before(
		time.Now().UTC(),
	) {
		return nil, errors.New(
			"registration deadline has passed",
		)
	}

	if event.AvailableSeats <= 0 {
		return nil, errors.New(
			"event is full",
		)
	}

	ticket, err := s.GetTicket(
		ctx,
		reg.TicketID,
	)

	if err != nil || ticket == nil {
		return nil, errors.New(
			"ticket not found",
		)
	}

	var existing models.Registration

	err = s.collection("registrations").
		FindOne(
			ctx,
			bson.M{
				"userId":  reg.UserID,
				"eventId": reg.EventID,
				"status":  "REGISTERED",
			},
		).
		Decode(&existing)

	if err == nil {
		return nil, errors.New(
			"user is already registered",
		)
	}

	reg.ID = uuid.NewString()
	reg.Status = "REGISTERED"
	reg.RegisteredAt = time.Now().UTC()

	_, err = s.collection("registrations").
		InsertOne(ctx, reg)

	if err != nil {
		return nil, err
	}

	// Decrease available seats.
	_, err = s.collection("events").
		UpdateOne(
			ctx,
			bson.M{
				"_id":            reg.EventID,
				"availableSeats": bson.M{"$gt": 0},
			},
			bson.M{
				"$inc": bson.M{
					"availableSeats": -1,
				},
			},
		)

	if err != nil {
		return nil, err
	}

	// Increase ticket sales.
	_, err = s.collection("tickets").
		UpdateOne(
			ctx,
			bson.M{"_id": ticket.ID},
			bson.M{
				"$inc": bson.M{
					"soldCount": 1,
				},
			},
		)

	if err != nil {
		return nil, err
	}

	return &reg, nil
}

func (s *Service) GetRegistrations(
	ctx context.Context,
	userID string,
	eventID string,
) ([]models.Registration, error) {

	filter := bson.M{}

	if userID != "" {
		filter["userId"] = userID
	}

	if eventID != "" {
		filter["eventId"] = eventID
	}

	return findMany[models.Registration](
		ctx,
		s.collection("registrations"),
		filter,
	)
}

func (s *Service) GetRegistration(
	ctx context.Context,
	id string,
) (*models.Registration, error) {

	return findOne[models.Registration](
		ctx,
		s.collection("registrations"),
		bson.M{"_id": id},
	)
}

func (s *Service) UpdateRegistration(
	ctx context.Context,
	id string,
	reg models.Registration,
) (*models.Registration, error) {

	update := bson.M{
		"$set": bson.M{
			"status": reg.Status,
		},
	}

	return findOneAndUpdate[models.Registration](
		ctx,
		s.collection("registrations"),
		bson.M{"_id": id},
		update,
	)
}

func (s *Service) DeleteRegistration(
	ctx context.Context,
	id string,
) error {

	result, err := s.collection("registrations").
		DeleteOne(
			ctx,
			bson.M{"_id": id},
		)

	if err != nil {
		return err
	}

	if result.DeletedCount == 0 {
		return errors.New(
			"registration not found",
		)
	}

	return nil
}

/* ------------CRUD for Attendance ------------- */
func (s *Service) CreateAttendance(
	ctx context.Context,
	attendance models.Attendance,
) (*models.Attendance, error) {

	registration, err := s.GetRegistration(
		ctx,
		attendance.RegistrationID,
	)

	if err != nil || registration == nil {
		return nil, errors.New(
			"registration not found",
		)
	}

	attendance.ID = uuid.NewString()
	attendance.EventID = registration.EventID
	attendance.CheckedInAt = time.Now().UTC()

	if attendance.Status == "" {
		attendance.Status = "CHECKED_IN"
	}

	_, err = s.collection("attendance").
		InsertOne(ctx, attendance)

	if err != nil {
		return nil, err
	}

	// Update registration status.
	_, err = s.collection("registrations").
		UpdateOne(
			ctx,
			bson.M{"_id": registration.ID},
			bson.M{
				"$set": bson.M{
					"status": "ATTENDED",
				},
			},
		)

	if err != nil {
		return nil, err
	}

	return &attendance, nil
}

func (s *Service) GetAttendance(
	ctx context.Context,
	eventID string,
) ([]models.Attendance, error) {

	filter := bson.M{}

	if eventID != "" {
		filter["eventId"] = eventID
	}

	return findMany[models.Attendance](
		ctx,
		s.collection("attendance"),
		filter,
	)
}

func (s *Service) GetAttendanceRecord(
	ctx context.Context,
	id string,
) (*models.Attendance, error) {

	return findOne[models.Attendance](
		ctx,
		s.collection("attendance"),
		bson.M{"_id": id},
	)
}

func (s *Service) UpdateAttendance(
	ctx context.Context,
	id string,
	attendance models.Attendance,
) (*models.Attendance, error) {

	update := bson.M{
		"$set": bson.M{
			"status":      attendance.Status,
			"checkedInBy": attendance.CheckedInBy,
		},
	}

	return findOneAndUpdate[models.Attendance](
		ctx,
		s.collection("attendance"),
		bson.M{"_id": id},
		update,
	)
}

func (s *Service) DeleteAttendance(
	ctx context.Context,
	id string,
) error {

	result, err := s.collection("attendance").
		DeleteOne(
			ctx,
			bson.M{"_id": id},
		)

	if err != nil {
		return err
	}

	if result.DeletedCount == 0 {
		return errors.New(
			"attendance record not found",
		)
	}

	return nil
}

