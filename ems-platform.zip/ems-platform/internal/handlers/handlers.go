package handlers

import (
	"ems-platform/internal/models"
	"ems-platform/internal/services"
	"strconv"

	"github.com/gin-gonic/gin"

	"net/http"
)


type Handler struct {
	service *services.Service
}

func New(service *services.Service) *Handler {
	return &Handler{
		service: service,
	}
}

//routes
func (h *Handler) RegisterRoutes(
	router *gin.Engine,
) {
	//health check

	router.GET("/health", h.health)

	api := router.Group("/api/v1")

	//users
	api.GET("/users", h.getUsers)
	api.GET("/users/:id", h.getUserById)
	api.POST("/users", h.createUser)
	api.PUT("/users/:id", h.updateUser)

	// Categories
	api.GET("/categories", h.getCategories)
	api.GET("/categories/:id", h.getCategory)
	api.POST("/categories", h.createCategory)
	api.PUT("/categories/:id", h.updateCategory)

	// Events
	api.GET("/events", h.getEvents)
	api.GET("/events/:id", h.getEvent)
	api.POST("/events", h.createEvent)
	api.PUT("/events/:id", h.updateEvent)
	api.DELETE("/events/:id", h.deleteEvent)
	api.POST("/events/:id/publish", h.publishEvent)

	// Tickets
	api.GET("/tickets", h.getTickets)
	api.GET("/tickets/:id", h.getTicket)
	api.POST("/tickets", h.createTicket)
	api.PUT("/tickets/:id", h.updateTicket)
	api.DELETE("/tickets/:id", h.deleteTicket)

	// Registrations
	api.GET("/registrations", h.getRegistrations)
	api.GET("/registrations/:id", h.getRegistration)
	api.POST("/registrations", h.createRegistration)
	api.PUT("/registrations/:id", h.updateRegistration)
	api.DELETE("/registrations/:id", h.deleteRegistration)

	// Attendance
	api.GET("/attendance", h.getAttendance)
	api.GET("/attendance/:id", h.getAttendanceRecord)
	api.POST("/attendance", h.createAttendance)
	api.PUT("/attendance/:id", h.updateAttendance)
	api.DELETE("/attendance/:id", h.deleteAttendance)

}

//error helper
func writeError(
	c *gin.Context,
	err error,
) {
	c.JSON(http.StatusBadRequest, gin.H{
		"error": err.Error(),
	},)
}

//for health check
func (h *Handler) health(c *gin.Context) {
	c.JSON(
		http.StatusOK,
		gin.H{
			"status": "UP",
			"service": "ems-platform",
		},
	)
}

//user handlers
func (h *Handler) getUsers(
	c *gin.Context,
) {
	users, err := h.service.GetAllUsers(c)

	if err != nil {
		writeError(c, err)
		return
	}

	c.JSON(http.StatusOK, users)
}

func (h *Handler) getUserById(c *gin.Context,) {
	user, err := h.service.GetUserById(c, c.Param("id"))

	if err != nil {
		writeError(c, err)
		return
	}

	if user == nil {
		c.JSON(
			http.StatusNotFound,
			gin.H{"error": "User Not Found"},
		)
	}

	c.JSON(http.StatusOK, user)
}

func (h *Handler) createUser(c *gin.Context) {
	var user models.User

	if err := c.ShouldBindJSON(&user); err != nil {
		writeError(c, err)
		return
	}

	result, err := h.service.CreateUser(
		c, 
		&user,)
	
	if err != nil {
		writeError(c, err)
		return
	}

	c.JSON(
		http.StatusCreated,
		result,
	)
}

func (h *Handler) updateUser(c *gin.Context) {
	var user models.User

	if err := c.ShouldBindJSON(&user); err != nil {
		writeError(c, err)
		return
	}

	result, err := h.service.UpdateUser(
		c, c.Param("id"), user,
	)

	if err != nil {
		writeError(c, err)
		return
	}

	c.JSON(
		http.StatusOK,
		result,
	)
}

/* ------------- category handlers ------------- */
func (h *Handler) getCategories(
	c *gin.Context,
) {

	result, err := h.service.GetCategories(c)

	if err != nil {
		writeError(c, err)
		return
	}

	c.JSON(http.StatusOK, result)
}

func (h *Handler) getCategory(
	c *gin.Context,
) {

	result, err := h.service.GetCategory(
		c,
		c.Param("id"),
	)

	if err != nil {
		writeError(c, err)
		return
	}

	if result == nil {
		c.JSON(
			http.StatusNotFound,
			gin.H{
				"error": "category not found",
			},
		)
		return
	}

	c.JSON(http.StatusOK, result)
}

func (h *Handler) createCategory(
	c *gin.Context,
) {

	var category models.Category

	if err := c.ShouldBindJSON(&category); err != nil {
		writeError(c, err)
		return
	}

	result, err := h.service.CreateCategory(
		c,
		category,
	)

	if err != nil {
		writeError(c, err)
		return
	}

	c.JSON(
		http.StatusCreated,
		result,
	)
}

func (h *Handler) updateCategory(
	c *gin.Context,
) {

	var category models.Category

	if err := c.ShouldBindJSON(&category); err != nil {
		writeError(c, err)
		return
	}

	result, err := h.service.UpdateCategory(
		c,
		c.Param("id"),
		category,
	)

	if err != nil {
		writeError(c, err)
		return
	}

	c.JSON(http.StatusOK, result)
}


/* ------------- event handlers ------------- */
func (h *Handler) getEvents(
	c *gin.Context,
) {

	var featured *bool

	if value := c.Query("featured"); value != "" {

		parsed, err := strconv.ParseBool(value)

		if err != nil {
			writeError(c, err)
			return
		}

		featured = &parsed
	}

	result, err := h.service.GetEvents(
		c,
		c.Query("search"),
		c.Query("categoryId"),
		featured,
	)

	if err != nil {
		writeError(c, err)
		return
	}

	c.JSON(http.StatusOK, result)
}

func (h *Handler) getEvent(
	c *gin.Context,
) {

	result, err := h.service.GetEvent(
		c,
		c.Param("id"),
	)

	if err != nil {
		writeError(c, err)
		return
	}

	if result == nil {
		c.JSON(
			http.StatusNotFound,
			gin.H{"error": "event not found"},
		)
		return
	}

	c.JSON(http.StatusOK, result)
}

func (h *Handler) createEvent(
	c *gin.Context,
) {

	var event models.Event

	if err := c.ShouldBindJSON(&event); err != nil {
		writeError(c, err)
		return
	}

	result, err := h.service.CreateEvent(
		c,
		event,
	)

	if err != nil {
		writeError(c, err)
		return
	}

	c.JSON(
		http.StatusCreated,
		result,
	)
}

func (h *Handler) updateEvent(
	c *gin.Context,
) {

	var event models.Event

	if err := c.ShouldBindJSON(&event); err != nil {
		writeError(c, err)
		return
	}

	result, err := h.service.UpdateEvent(
		c,
		c.Param("id"),
		event,
	)

	if err != nil {
		writeError(c, err)
		return
	}

	c.JSON(http.StatusOK, result)
}

func (h *Handler) deleteEvent(
	c *gin.Context,
) {

	err := h.service.DeleteEvent(
		c,
		c.Param("id"),
	)

	if err != nil {
		writeError(c, err)
		return
	}

	c.Status(http.StatusNoContent)
}

func (h *Handler) publishEvent(
	c *gin.Context,
) {

	result, err := h.service.PublishEvent(
		c,
		c.Param("id"),
	)

	if err != nil {
		writeError(c, err)
		return
	}

	c.JSON(http.StatusOK, result)
}

/* ------------- ticket handlers ------------- */
func (h *Handler) getTickets(
	c *gin.Context,
) {

	result, err := h.service.GetTickets(
		c,
		c.Query("eventId"),
	)

	if err != nil {
		writeError(c, err)
		return
	}

	c.JSON(http.StatusOK, result)
}

func (h *Handler) getTicket(
	c *gin.Context,
) {

	result, err := h.service.GetTicket(
		c,
		c.Param("id"),
	)

	if err != nil {
		writeError(c, err)
		return
	}

	if result == nil {
		c.JSON(
			http.StatusNotFound,
			gin.H{"error": "ticket not found"},
		)
		return
	}

	c.JSON(http.StatusOK, result)
}

func (h *Handler) createTicket(
	c *gin.Context,
) {

	var ticket models.Ticket

	if err := c.ShouldBindJSON(&ticket); err != nil {
		writeError(c, err)
		return
	}

	result, err := h.service.CreateTicket(
		c,
		ticket,
	)

	if err != nil {
		writeError(c, err)
		return
	}

	c.JSON(
		http.StatusCreated,
		result,
	)
}

func (h *Handler) updateTicket(
	c *gin.Context,
) {

	var ticket models.Ticket

	if err := c.ShouldBindJSON(&ticket); err != nil {
		writeError(c, err)
		return
	}

	result, err := h.service.UpdateTicket(
		c,
		c.Param("id"),
		ticket,
	)

	if err != nil {
		writeError(c, err)
		return
	}

	c.JSON(http.StatusOK, result)
}

func (h *Handler) deleteTicket(
	c *gin.Context,
) {

	err := h.service.DeleteTicket(
		c,
		c.Param("id"),
	)

	if err != nil {
		writeError(c, err)
		return
	}

	c.Status(http.StatusNoContent)
}

/* ------------- registration handlers ------------- */
func (h *Handler) getRegistrations(
	c *gin.Context,
) {

	result, err := h.service.GetRegistrations(
		c,
		c.Query("userId"),
		c.Query("eventId"),
	)

	if err != nil {
		writeError(c, err)
		return
	}

	c.JSON(http.StatusOK, result)
}

func (h *Handler) getRegistration(
	c *gin.Context,
) {

	result, err := h.service.GetRegistration(
		c,
		c.Param("id"),
	)

	if err != nil {
		writeError(c, err)
		return
	}

	if result == nil {
		c.JSON(
			http.StatusNotFound,
			gin.H{
				"error": "registration not found",
			},
		)
		return
	}

	c.JSON(http.StatusOK, result)
}

func (h *Handler) createRegistration(
	c *gin.Context,
) {

	var registration models.Registration

	if err := c.ShouldBindJSON(
		&registration,
	); err != nil {
		writeError(c, err)
		return
	}

	result, err := h.service.CreateRegistration(
		c,
		registration,
	)

	if err != nil {
		writeError(c, err)
		return
	}

	c.JSON(
		http.StatusCreated,
		result,
	)
}

func (h *Handler) updateRegistration(
	c *gin.Context,
) {

	var registration models.Registration

	if err := c.ShouldBindJSON(
		&registration,
	); err != nil {
		writeError(c, err)
		return
	}

	result, err := h.service.UpdateRegistration(
		c,
		c.Param("id"),
		registration,
	)

	if err != nil {
		writeError(c, err)
		return
	}

	c.JSON(http.StatusOK, result)
}

func (h *Handler) deleteRegistration(
	c *gin.Context,
) {

	err := h.service.DeleteRegistration(
		c,
		c.Param("id"),
	)

	if err != nil {
		writeError(c, err)
		return
	}

	c.Status(http.StatusNoContent)
}

/* ------------- attendance handlers ------------- */
func (h *Handler) getAttendance(
	c *gin.Context,
) {

	result, err := h.service.GetAttendance(
		c,
		c.Query("eventId"),
	)

	if err != nil {
		writeError(c, err)
		return
	}

	c.JSON(http.StatusOK, result)
}

func (h *Handler) getAttendanceRecord(
	c *gin.Context,
) {

	result, err := h.service.GetAttendanceRecord(
		c,
		c.Param("id"),
	)

	if err != nil {
		writeError(c, err)
		return
	}

	if result == nil {
		c.JSON(
			http.StatusNotFound,
			gin.H{
				"error": "attendance record not found",
			},
		)
		return
	}

	c.JSON(http.StatusOK, result)
}

func (h *Handler) createAttendance(
	c *gin.Context,
) {

	var attendance models.Attendance

	if err := c.ShouldBindJSON(
		&attendance,
	); err != nil {
		writeError(c, err)
		return
	}

	result, err := h.service.CreateAttendance(
		c,
		attendance,
	)

	if err != nil {
		writeError(c, err)
		return
	}

	c.JSON(
		http.StatusCreated,
		result,
	)
}

func (h *Handler) updateAttendance(
	c *gin.Context,
) {

	var attendance models.Attendance

	if err := c.ShouldBindJSON(
		&attendance,
	); err != nil {
		writeError(c, err)
		return
	}

	result, err := h.service.UpdateAttendance(
		c,
		c.Param("id"),
		attendance,
	)

	if err != nil {
		writeError(c, err)
		return
	}

	c.JSON(http.StatusOK, result)
}

func (h *Handler) deleteAttendance(
	c *gin.Context,
) {

	err := h.service.DeleteAttendance(
		c,
		c.Param("id"),
	)

	if err != nil {
		writeError(c, err)
		return
	}

	c.Status(http.StatusNoContent)
}
