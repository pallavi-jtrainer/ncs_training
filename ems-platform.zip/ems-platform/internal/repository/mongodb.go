package repository

import (
	"context"
	"time"

	"ems-platform/internal/config"

	"go.mongodb.org/mongo-driver/v2/mongo"
	"go.mongodb.org/mongo-driver/v2/mongo/options"
)

type MongoRepository struct {
	Client *mongo.Client
	DB *mongo.Database
}

func NewMongoRepository (
	ctx context.Context,
	cfg config.Config,
) (*MongoRepository, error) {

	client, err := mongo.Connect(options.Client().ApplyURI(cfg.MongoURI))

	if err != nil {
		return nil, err
	}

	pingCtx, cancel := context.WithTimeout(
		ctx, 5*time.Second,
	)
	defer cancel()

	if err := client.Ping(pingCtx, nil); err != nil {
		_ = client.Disconnect(ctx)
		return nil, err
	}

	return &MongoRepository{
		Client: client,
		DB: client.Database(cfg.MongoDBName),
	}, nil
}

func (r *MongoRepository) Close(ctx context.Context) error {
	return r.Client.Disconnect(ctx);
}
