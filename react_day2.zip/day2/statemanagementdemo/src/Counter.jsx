import { useState } from 'react';

export function Counter() {

    // count = 0; setCount(count) {count = count+1}
    const [ count, setCount ] = useState(0);

    return (
      <div>
        <p>Count: {count}</p>
        <button onClick={() => setCount(count + 1)}>Increment Counter</button>
        <button onClick={() => setCount(count - 1)}>Decrement Counter</button>
      </div>
    );
}