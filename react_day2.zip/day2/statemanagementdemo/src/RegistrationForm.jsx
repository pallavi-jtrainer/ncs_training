import { useState } from "react";


export function RegistrationForm() {
    // const [ firstname, setFirstname ] = useState('');
    // const [ lastname, setLastName ] = useState('');
    // const [ email, setEmail ] = useState('');
    // const [ password, setPassword ] = useState('');
    // const [ confirmPassword, setConfirmPassword ] = useState('');

    // users
    const [ users, setUsers ] = useState([]);

    const [ formData, setFormData ] = useState({
        firstName: "",
        lastName: "",
        email: "",
        password: "",
        confirmPassword: "",
        gender: "",
        phone: "",
        terms: false
    });

    const [ message, setMessage ] = useState("")

    //event handlers
    const handleChange = (e) => {
        const { name, type, value, checked } = e.target;

        // const name = e.target.name;

        setFormData( {
            ...formData,
            [name]:type === "checkbox" ? checked : value
        })

    }

    const handleSubmit = (e) => {
        e.preventDefault();

        if(formData.password !== formData.confirmPassword) {
            setMessage("Password Mismatch. Please enter again!");
        }

        //create new user
        const newUser = {
            id: users.length + 1,
            firstName: formData.firstName,
            lastName: formData.lastName,
            email: formData.email,
            phone: formData.phone,
            gender: formData.gender,
            password: formData.password
        };

        // setUsers([...users, newUser]);
        setUsers(
            (prev) => {
                const updatedUsers = [...prev, newUser]
                console.log("Updated Users: ",updatedUsers)

                return updatedUsers;
            }
        );
        console.log("New User: ", newUser);
        console.log(users);

        if(users.length > 0) {
            setMessage("Registration Successful!");
        } else {
            setMessage("Unable to Add User");
        }

        setFormData({
          firstName: "",
          lastName: "",
          email: "",
          password: "",
          confirmPassword: "",
          gender: "",
          phone: "",
          terms:false
        });
        
    }

    return (
      <div className="container">
        <div className="row justify-content-center mt-5">
          <div className="card shadow">
            <div className="card-header bg-secondary text-white text-center">
              <h3 className="mb-0">Create Account</h3>
            </div>
            <div className="card-body">
              {message && <div className="alert alert-info">{message}</div>}

              <form onSubmit={handleSubmit}>
                <div className="mb-3">
                  <label className="form-label">First Name:</label>
                  <input
                    type="text"
                    name="firstName"
                    className="form-control"
                    placeholder="Enter your First Name"
                    value={formData.firstName}
                    onChange={handleChange}
                    required
                  />
                </div>
                <div className="mb-3">
                  <label className="form-label">Last Name:</label>
                  <input
                    type="text"
                    name="lastName"
                    className="form-control"
                    placeholder="Enter your Last Name"
                    value={formData.lastName}
                    onChange={handleChange}
                    required
                  />
                </div>
                <div className="mb-3">
                  <label className="form-label">Email:</label>
                  <input
                    type="email"
                    name="email"
                    className="form-control"
                    placeholder="Enter your Email"
                    value={formData.email}
                    onChange={handleChange}
                    required
                  />
                </div>
                <div className="mb-3">
                  <label className="form-label">Contact Number:</label>
                  <input
                    type="tel"
                    name="phone"
                    className="form-control"
                    placeholder="Enter your Phone Number"
                    value={formData.phone}
                    onChange={handleChange}
                    required
                  />
                </div>
                <div className="mb-3">
                  <label className="form-label">Password:</label>
                  <input
                    type="password"
                    name="password"
                    className="form-control"
                    placeholder="Enter Password"
                    value={formData.password}
                    onChange={handleChange}
                    required
                  />
                </div>
                <div className="mb-3">
                  <label className="form-label">Confirm Password:</label>
                  <input
                    type="password"
                    name="confirmPassword"
                    className="form-control"
                    placeholder="Confirm Your Password"
                    value={formData.confirmPassword}
                    onChange={handleChange}
                    required
                  />
                </div>
                <div className="mb-3">
                  <label className="form-label">Gender:</label>
                  <div className="form-check form-check-inline">
                    <input
                      type="radio"
                      name="gender"
                      className="form-check-input"
                      value="Male"
                      checked={formData.gender === "Male"}
                      onChange={handleChange}
                      required
                    />
                    <label className="form-check-label">Male</label>
                  </div>
                  <div className="form-check form-check-inline">
                    <input
                      type="radio"
                      name="gender"
                      className="form-check-input"
                      value="Female"
                      checked={formData.gender === "Female"}
                      onChange={handleChange}
                      required
                    />
                    <label className="form-check-label">Female</label>
                  </div>
                </div>
                <div className="mb-3 form-check">
                    <input 
                        type="checkbox"
                        name="terms"
                        className="form-check-input"
                        checked={formData.terms}
                        onChange={handleChange}
                    />
                    <label className="form-check-label">
                        I agree to the Terms and Conditions
                    </label>
                </div>
                <div className="d-grid">
                  <button type="submit" className="btn btn-primary btn-lg">
                    Register
                  </button>
                </div>
              </form>
            </div>
            <div className="card-footer text-center">
              Already have an Account?
              <a href="#" className="ms-1 text-decoration-none">
                Login
              </a>
            </div>
          </div>
        </div>
      </div>
    );





}