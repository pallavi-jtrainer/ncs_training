import { useState } from "react";

// exercise 1: add a completed status to the todo. write a toggle method. status has to boolean. have a button or check box to toggle status.
// exercise 2: print the count of completed tasks.

export function TodoList() {

    const [ todos, setTodos] = useState([]);
    const [ input, setInput] = useState('');

    //event handlers
    // 1. add a todo
    const addTodo = () => {
        if(input.trim()) {
            setTodos([...todos, {id: Date.now(), text: input, completed: false}])
            setInput('')
        }
    };

    // 2. remove todo
    const removeTodo = (id) => {
        setTodos(todos.filter(todo => todo.id !== id))
    };

    // 3. toggleComplete
    const toggleComplete = (id) => {
        setTodos(todos.map(todo => todo.id === id ? { ...todo, completed: !todo.completed} : todo));
    };

    //count of completed tasks
    const completedTodosCount = todos.filter(t => t.completed).length;
    const totalCount = todos.length;

    return (
      <div>
        <div>
          <h3>My Todo List</h3>
        </div>
        <div>
          <p>
            Completed Tasks: {completedTodosCount} / {totalCount}
          </p>
        </div>
        <div>
          <input
            value={input}
            placeholder="Add a Todo"
            onChange={(e) => setInput(e.target.value)}
            type="text"
          />
          <button onClick={addTodo}>Add Todo</button>

          <div>
            <ul>
              {todos.map((todo) => (
                <li key={todo.id}>
                  <input
                    type="checkbox"
                    checked={todo.completed}
                    onChange={() => toggleComplete(todo.id)}
                  />
                  <span>{todo.text}</span>
                  <button onClick={() => removeTodo(todo.id)}>
                    Delete Todo
                  </button>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    );
}