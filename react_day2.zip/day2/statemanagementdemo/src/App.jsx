// import { Counter } from "./Counter";
// import { TodoList } from "./TodoList";

import { RegistrationForm } from "./RegistrationForm";


function App() {
  return (
    // <Counter />
    // <TodoList/>
    <RegistrationForm />
  )
}

export default App