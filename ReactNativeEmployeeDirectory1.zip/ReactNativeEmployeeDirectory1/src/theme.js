// css objects only
export const colors = {
  primary: "#4f46e5",
  primaryDark: "#3730a3",
  background: "#f3f4f6",
  surface: "#ffffff",
  text: "#111827",
  textMuted: "#6b7280",
  border: "#e5e7eb",
  danger: "#dc2626",
  star: "#f59e05",
  warn: "#e0b818e0",
  info: "#46cde5",
};

export const spacing = {
    xs: 4,
    sm: 8,
    md: 16,
    lg: 24,
    xl: 32,
};

