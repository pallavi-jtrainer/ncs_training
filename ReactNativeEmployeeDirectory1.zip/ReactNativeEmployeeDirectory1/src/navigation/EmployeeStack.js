import { createStackNavigator } from '@react-navigation/stack';

import EmployeeListScreen from '../screens/EmployeeListScreen';

const Stack = createStackNavigator();

export default function EmployeeStack() {
    return(
        <Stack.Navigator>
            <Stack.Screen
                name="EmployeeList"
                component={EmployeeListScreen}
                options={{
                    title: 'Employees'
                }}
            />
        </Stack.Navigator>
    );
}