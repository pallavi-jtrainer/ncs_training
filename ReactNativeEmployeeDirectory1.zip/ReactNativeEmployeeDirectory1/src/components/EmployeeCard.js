import { View, Text, StyleSheet, Button, Pressable } from "react-native";
import {colors,  spacing } from '../theme.js';

export default function EmployeeCard({ name, role, dept }) {
//     console.log(employee);
//    const {name, role, dept} = employee;
  //  console.log(name);
    return (
        <View style={styles.card}>
            <Text style={styles.name}>{name}</Text>
            <Text style={styles.role}>{role}</Text>
            <Text style={styles.dept}>{dept}</Text>
            {/* <Button title="View Profile" onPress={() => {
                console.log('View profile pressed')
            }}/> */}
            <Pressable onPress={() => {
                console.log("Pressed View Profile")
            }} style={styles.button}>
                <Text style={styles.buttonText}>View Profile</Text>
            </Pressable>
        </View>
    )
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: colors.surface,
    padding: spacing.md,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: colors.border,
  },
  name: {
    fontSize: 17,
    fontWeight: "700",
    color: colors.text,
  },
  role: {
    fontSize: 14,
    color: colors.textMuted,
    marginTop: 2,
  },
  dept: {
    fontSize: 14,
    fontWeight: "600",
    color: colors.primary,
    marginTop: spacing.xs,
  },
  button: {
    padding: 10,
    borderRadius: 8,
    marginTop: 10,
    backgroundColor: "#578EF5",
  },
  buttonText: {
    fontWeight: 'bold',
    color: '#ffffff',
    justifyContent: 'center',
    alignItems: 'center'
  }
});