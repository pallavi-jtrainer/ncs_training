export const employees = [
  {
    id: 1,
    firstname: "Prithvi",
    lastname: "Raj",
    email: "prithvi.r@example.com",
    role: "Data Analyst",
    department: "Data Services",
  },
];
