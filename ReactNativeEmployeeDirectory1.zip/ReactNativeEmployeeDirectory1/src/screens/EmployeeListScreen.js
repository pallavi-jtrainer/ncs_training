import {View, Text, Pressable, StyleSheet, FlatList} from 'react-native';

import employees from '../data/employees'

export default function EmployeeListScreen({navigation}) {
    return (
        <View>
            <FlatList
                data={employees}
                keyExtractor={(item) => item.id}
                renderItem={({item}) => (
                    <Pressable 
                      onPress={() => {
                        navigation.navigate('EmployeeDetails', {
                            employee:item
                        })
                      }}>
                        <Text>{item.firstname} {item.lastname}</Text>
                        <Text>{item.role}</Text>
                      </Pressable>
                )}
            ></FlatList>
        </View>
    );
}