import { View, Text, Pressable, StyleSheet } from 'react-native';

export default function HomeScreen({navigation}) {

    return(
        <View style={styles.container}>
            <Text style={styles.title}>Employee Directory</Text>
            <Text>Welcome to the Employee Directory!</Text>
            <Pressable
                onPress={() => {
                    navigation.navigate('Employees');
                }}
                style={styles.button}>
                    <Text>View Employees</Text>
                </Pressable>
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        padding: 20
    },

    title: {
        fontSize: 24,
        fontWeight: 'bold',
        marginBottom:10,
    },

    button: {
        marginTop: 20,
        padding: 12,
        borderWidth: 1,
        borderRadius: 8
    }
})