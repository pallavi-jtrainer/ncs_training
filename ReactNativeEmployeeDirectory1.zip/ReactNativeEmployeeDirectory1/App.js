// import { StatusBar } from 'expo-status-bar';
// import { StatusBar } from 'expo-status-bar';
import { StyleSheet, Text, View } from 'react-native';
// import { SafeAreaProvider, SafeAreaView } from 'react-native-safe-area-context';
import HomeScreen from './src/screens/HomeScreen';
import EmployeeStack from './src/navigation/EmployeeStack';
//import EmployeeCard from './src/components/EmployeeCard';

export default function App() {
  // const name = 'Pallavi Prasad';
  // const role = 'Trainer';
  // const dept = 'Tech Training';

  // const emp = {
  //   name: 'Prithvi Raj',
  //   role: 'Data Analyst',
  //   dept: 'Data Analysis'
  // }
  
  // return (
  //   // <SafeAreaProvider>
  //   //   <SafeAreaView style={styles.container}>
  //       // <StatusBar style="dark">
  //         <View style={styles.box}>
  //           {/* <Text style={styles.title}>Welcome to Employee Directory!</Text> */}
  //           {/* <EmployeeCard name={name} role={role} dept={dept}/> */}
  //           {/* <EmployeeCard name='Priya Sharma' role='Retail Sales'/> */}
  //           {/* <EmployeeCard employee={emp}/> */}
  //           <HomeScreen />
  //         </View>
  //       // </StatusBar>
  //   //   </SafeAreaView>
  //   // </SafeAreaProvider>
  // );
  return (
    <View style={styles.box}>
      {/* <EmployeeStack /> */}
      <HomeScreen />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#FCF9EA",
  },
  box: {
    padding: 24,
    width: 360
 //   flexDirection: 'col',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 8,
    color: 'black',
    // alignItems: 'center',
    // justifyContent:'center'
   // flexShrink: 1
  },
});