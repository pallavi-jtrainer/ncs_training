// import { useState } from 'react'
// import './App.css'

import { Header } from "./components/Header";
import { ProductList } from "./components/ProductList";

function App() {
  // const name = "Pallavi";

  // const product = {
  //   name: "Laptop",
  //   price:"75000"
  // }

  const products = [
    {id: 1, pname:"Dell Laptop", price: 75000},
    {id: 2, pname:"Lenovo Laptop", price: 80000},
    {id: 3, pname: "Macbook Air", price: 105000},
  ]
  
  return (
    <>
      <Header/>
      <ProductList products={products}/>
      {/* <h1>Welcome to React, {name}!</h1> */}
      {/* <Header product={product}/> */}
      {/* <div>
        <h2> Welcome to React</h2>
        <p>This is a React functional component</p>
      </div>
      <div>
        <input type="text"/>
        <button>Click</button>
      </div> */}
    </>
  );
}

export default App
