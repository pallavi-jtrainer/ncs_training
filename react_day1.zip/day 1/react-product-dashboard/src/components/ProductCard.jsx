
export function ProductCard({product}) {
    return(
        <div>
            <h3>{product.pname}</h3>
            <p>{product.price}</p>
        </div>
    )
}