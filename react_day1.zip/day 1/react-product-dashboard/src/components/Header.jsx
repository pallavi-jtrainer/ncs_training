import "./Header.css"

export function Header() {

    return (
      <div>
        <header>
          <h1>Product Dashboard</h1>
          <p>Manage your products</p>
        </header>
        {/* <div>
            <h3>Product Details</h3>
            <p>Name: {product.name}</p>
            <p>Price: ${product.price}</p>
        </div> */}
      </div>
    );
}

// export default Header;