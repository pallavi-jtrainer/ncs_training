// import { ProductCard } from "./ProductCard";

export function ProductList({products}) {

    return (
      <>
        <h3>Product List</h3>
        <div>
            {/* {products.map(product => (
                <ProductCard 
                    key={product.id}
                    product={product}
                />
            ))} */}
          <table>
            <thead>
              <tr>
                <th>Id</th>
                <th>Name</th>
                <th>Price</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>{products[0].id}</td>
                <td>{products[0].pname}</td>
                <td>{products[0].price}</td>
              </tr>
              <tr>
                <td>{products[1].id}</td>
                <td>{products[1].pname}</td>
                <td>{products[1].price}</td>
              </tr>
              <tr>
                <td>{products[2].id}</td>
                <td>{products[2].pname}</td>
                <td>{products[2].price}</td>
              </tr>
            </tbody>
          </table>
        </div>
      </>
    );
}