function clickMe() {
  content = document.getElementById("text1").value;
  alert("Hello " + content);
}
